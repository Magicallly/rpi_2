$.modal = function (params){
    const $modal = _createModal(params);
    let isClosing = false;
    let isDestroyed = false;
    let content;

    const modal = {
        open() {
            if (!isDestroyed && !isClosing) {
                $modal.classList.add('open');
                document.body.classList.add('modal-open');
            }
        },
        close() {
            if (!isDestroyed) {
                $modal.classList.remove('open');
                $modal.classList.add('close');
                document.body.classList.remove('modal-open');
                isClosing = true;
                setTimeout(() => {
                    $modal.classList.remove('close')
                }, 500);
                isClosing = false;
            }
        }
    }

    $modal.addEventListener('click', ev => {
        if (ev.target.dataset.close) {
            modal.close();
        }
    });

    function _createModal(params){
        const modal = document.createElement("div");
        if (params.id) {
            modal.id = params.id;
        }
        modal.classList.add("modal");

        modal.insertAdjacentHTML("afterbegin", `
        <div class="modal-overlay" data-close="true">
            <div class="modal-window">
                <div class="modal-header">
                    <span class="modal-title">
                        ${params.title || ''}
                    </span>
                    <span class="modal-close" data-close="true">
                        &times;
                    </span>
                </div>
                <div class="modal-body" data-content>
                </div>
                <div class="modal-footer">

                </div>
            </div>
        </div>
        `);
        document.body.appendChild(modal);
        return modal;
    }

    return Object.assign(modal, {
        destroy() {
            $modal.remove();
            isDestroyed = true;
        },
        getMessages() {
            let xmlHttpRequest = new XMLHttpRequest();
            xmlHttpRequest.responseType = "json";

            xmlHttpRequest.open('GET', 'https://rpi-lab2.herokuapp.com/api/message');
            xmlHttpRequest.send();

            let answer;
            content = '';

            xmlHttpRequest.onreadystatechange = function () {
                if (xmlHttpRequest.readyState !== 4) {
                    return;
                }

                if (xmlHttpRequest.status === 200) {
                    console.log('result', xmlHttpRequest.response);

                    answer = Object.values(xmlHttpRequest.response);

                    for(let i = 0; i < answer.length; i++){
                        content += `<div class="modal-message">
                                    <div class="modal-message-sender">${answer[i]["userName"]}:</div>
                                    <div class="modal-message-content">${answer[i]["message"]}</div>
                                </div>`;
                    }
                } else {
                    console.log('err', xmlHttpRequest.response);
                }
            }
            xmlHttpRequest.onloadend = function (){
                $modal.querySelector('[data-content]').innerHTML = content ? content : '';
            }
        }
    });
}