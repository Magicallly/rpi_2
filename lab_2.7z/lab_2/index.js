const modal = $.modal(
    {
        id: "MessagesModal",
        title: "Messages"
    }
);

modal.getMessages();

modal.open();
